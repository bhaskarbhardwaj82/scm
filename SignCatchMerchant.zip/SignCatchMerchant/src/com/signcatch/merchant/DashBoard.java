package com.signcatch.merchant;

import static com.signcatch.merchant.CommonUtilities.DISPLAY_MESSAGE_ACTION;
import static com.signcatch.merchant.CommonUtilities.EXTRA_MESSAGE;
import static com.signcatch.merchant.CommonUtilities.SENDER_ID;
import static com.signcatch.merchant.CommonUtilities.SERVER_URL;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.android.gcm.GCMRegistrar;

public class DashBoard extends Activity {
	private clsGeneral objGeneral;
	private Runnable runnable;
	Boolean running = false;
	private Handler handler = new Handler();
	String url = "";
	Handler h = new Handler();
	Context mContext;
	Activity mActivity;
	String userName;
	Button btnGenerate, btnHistory, btnSettings, btnUpdate, btnLogout,
			btnDisplay, imgBtnHelp;

	// ImageButton btnScan;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dashboard);
		init();

		if (objGeneral.getSharedPreferencesValue(getApplicationContext(),
				"PUSHNOTIFICATION").equals("0") == false) {
			objGeneral.setSharedPreferencesValue(getApplicationContext(),
					"PUSHNOTIFICATION", "1");
		}
		//CheckAndRegisterPushNotification();

		btnGenerate = (Button) findViewById(R.id.imgBtnGenerate);
		btnHistory = (Button) findViewById(R.id.imgBtnHistory);
		btnSettings = (Button) findViewById(R.id.imgBtnSetting);
		btnUpdate = (Button) findViewById(R.id.imgBtnUpdate);
		btnDisplay = (Button) findViewById(R.id.imgbtnShowSignCatch);
		btnLogout = (Button) findViewById(R.id.btnLogout);
		imgBtnHelp = (Button) findViewById(R.id.imgBtnHelp);
		updatebuttonsizes();
		
		imgBtnHelp.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				userName=objGeneral.getSharedPreferencesValue(
						getApplicationContext(), "UserID");
				Bundle bundle = new Bundle();
				bundle.putString("userName", userName);
				Intent help = new Intent(DashBoard.this, Help.class);
				help.putExtras(bundle);
				startActivity(help);
			}
		});
		btnLogout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
				builder.setMessage("You want to Exit?")
						.setCancelable(false)
						.setNegativeButton("No",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface arg0,
											int arg1) {
										arg0.dismiss();
									}
								})
						.setPositiveButton("Yes",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int id) {
										
										Intent ittLogin = new Intent(
												mContext, Login.class);
										startActivity(ittLogin);
										mActivity.finish();
									}
								});
				AlertDialog alert = builder.create();
				try {
					alert.show();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}
		});

		btnGenerate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent ittAddProduct = new Intent(mContext, AddProduct.class);
				startActivity(ittAddProduct);

			}
		});

		btnHistory.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent ittTransactions = new Intent(mContext, History.class);
				startActivity(ittTransactions);

			}
		});
		btnSettings.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent ittSettings = new Intent(mContext, Settings.class);
				startActivity(ittSettings);

			}
		});

		btnUpdate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				userName=objGeneral.getSharedPreferencesValue(
						getApplicationContext(), "UserID");
				Bundle bundle = new Bundle();
				bundle.putString("userName", userName);
				Intent ittUpdate = new Intent(mContext, Update.class);
				ittUpdate.putExtras(bundle);
				
				startActivity(ittUpdate);

			}
		});

		btnDisplay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent ittAutoShowSignCatch = new Intent(mContext,
						AutoShowSignCatch.class);
				startActivity(ittAutoShowSignCatch);

			}
		});

	}
	private void updatebuttonsizes()
	{
		 Display display = getWindowManager().getDefaultDisplay();
			int SCREEN_WIDTH = display.getWidth();
			int SCREEN_HEIGHT = display.getHeight();
			
			int size = (SCREEN_WIDTH / 1)/3;
			ViewGroup.LayoutParams params1 = btnGenerate.getLayoutParams();
			ViewGroup.LayoutParams params2 = btnHistory.getLayoutParams();
			ViewGroup.LayoutParams params3 = btnSettings.getLayoutParams();
			ViewGroup.LayoutParams params4 = btnUpdate.getLayoutParams();
			ViewGroup.LayoutParams params5 = btnDisplay.getLayoutParams();
			ViewGroup.LayoutParams params6 = imgBtnHelp.getLayoutParams();
			
			if(size<105)
			{
				size = 105;
			}	
			params1.width = size;
			params2.width = size;
			params3.width = size;
			params4.width = size;
			params5.width = size;
			params6.width = size;
			btnGenerate.setLayoutParams(params1);
			btnHistory.setLayoutParams(params2);
			btnSettings.setLayoutParams(params3);
			btnUpdate.setLayoutParams(params4);
			btnDisplay.setLayoutParams(params5);
			imgBtnHelp.setLayoutParams(params6);
	}
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
	    super.onConfigurationChanged(newConfig);
	    updatebuttonsizes();
	}
	private void init() {
		objGeneral = new clsGeneral();
		objGeneral.InitLoadPopup(this,
				(ViewGroup) findViewById(R.id.layout_root));
		mContext = DashBoard.this;
		mActivity = DashBoard.this;
		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}

	AsyncTask<Void, Void, Void> mRegisterTask;

	private void CheckAndRegisterPushNotification() {
		try {
			checkNotNull(SERVER_URL, "SERVER_URL");
			checkNotNull(SENDER_ID, "SENDER_ID");
			GCMRegistrar.checkDevice(this);
			GCMRegistrar.checkManifest(this);
			// mDisplay = (TextView) findViewById(R.id.display);
			registerReceiver(mHandleMessageReceiver, new IntentFilter(
					DISPLAY_MESSAGE_ACTION));
			final String regId = GCMRegistrar.getRegistrationId(this);
			if (regId.equals("")) {
				// Automatically registers application on startup.
				GCMRegistrar.register(this, SENDER_ID);
				String Userid = objGeneral.getSharedPreferencesValue(getApplicationContext(), "UserID");
				objGeneral.setSharedPreferencesValue(getApplicationContext(),
						"OLDUSERID", Userid);
			} else {
				// Device is already registered on GCM, check server.
				if (GCMRegistrar.isRegisteredOnServer(this)) {
					// Skips registration.
					// mDisplay.append(getString(R.string.already_registered) +
					// "\n");
					Log.println(1, "pshntf", getString(R.string.already_registered));
					String OldUserid = objGeneral.getSharedPreferencesValue(getApplicationContext(), "OLDUSERID");
					String Userid = objGeneral.getSharedPreferencesValue(getApplicationContext(), "UserID");

					if(Userid.equals(OldUserid)==false)
					{
						GCMRegistrar.unregister(this);
						GCMRegistrar.register(this, SENDER_ID);
						objGeneral.setSharedPreferencesValue(getApplicationContext(),
								"OLDUSERID", Userid);

					}
					
					objGeneral.setSharedPreferencesValue(getApplicationContext(),
							"PUSHNOTIFICATION", "1");
				} else {
					// Try to register again, but not in the UI thread.
					// It's also necessary to cancel the thread onDestroy(),
					// hence the use of AsyncTask instead of a raw thread.
					final Context context = this;
					mRegisterTask = new AsyncTask<Void, Void, Void>() {

						@Override
						protected Void doInBackground(Void... params) {
							ServerUtilities.register(context, regId);
							return null;
						}

						@Override
						protected void onPostExecute(Void result) {
							mRegisterTask = null;
						}

					};
					mRegisterTask.execute(null, null, null);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void checkNotNull(Object reference, String name) {
		if (reference == null) {
			throw new NullPointerException(getString(R.string.error_config,
					name));
		}
	}

	private final BroadcastReceiver mHandleMessageReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String newMessage = intent.getExtras().getString(EXTRA_MESSAGE);
			Log.println(1, "pshntf", newMessage);
			// mDisplay.append(newMessage + "\n");
		}
	};
}
