package com.signcatch.merchant;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class clsGeneral {

	public AlertDialog.Builder builder;
	public AlertDialog alertDialog;
	// public String NOINTERNET =
	// "No Internet Connections!! Please try again..";
	public String NOINTERNET = "Communication Failure!! Please try again..";

	public Boolean CheckInternet(Context context) {
		try {
			ConnectivityManager cm = (ConnectivityManager) context
					.getSystemService(context.CONNECTIVITY_SERVICE);
			Object obj = cm.getActiveNetworkInfo().isConnectedOrConnecting();
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public Boolean isInternetAvailable() {
		try {
			URL url = new URL("http://www.google.com");
			HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
			urlc.setRequestProperty("User-Agent", "Android Application:8");
			// myHttpURLConnection.setRequestProperty("Content-Type",
			// "text/plain; charset=utf-8");
			// myHttpURLConnection.setRequestProperty("Expect", "100-continue");

			urlc.setRequestProperty("Connection", "close");
			urlc.setConnectTimeout(1000 * 30); // mTimeout is in seconds
			urlc.connect();
			if (urlc.getResponseCode() == 200) {
				return new Boolean(true);
			}
			return true;
		} catch (IOException e) {
			return false;
		}
	}

	public void InitLoadPopup(Context context, ViewGroup viewGroup) {
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(context.LAYOUT_INFLATER_SERVICE);
		View layout = inflater.inflate(R.layout.loaddialog, viewGroup);
		builder = new AlertDialog.Builder(context);
		builder.setView(layout);
		alertDialog = builder.create();
		alertDialog.setIcon(R.drawable.logo);
		alertDialog.setInverseBackgroundForced(false);

	}

	public void ShowLoadPopup() {
		try {

			alertDialog.show();
		} catch (Exception ex) {

		}
	}

	public void HideLoadPopup() {
		try {

			alertDialog.hide();
		} catch (Exception ex) {

		}
	}

	public String makeDateString(int mDay, int mMonth, int mYear) {
		StringBuilder sblTmp = new StringBuilder()
				// Month is 0 based so add 1
				.append(mDay).append("-").append(mMonth + 1).append("-")
				.append(mYear).append(" ");
		return sblTmp.toString();

	}

	public String makeTimeString(int mHour, int mMinute) {
		StringBuilder sblTmp = new StringBuilder() // Month is 0 based so add 1
				.append(mHour).append(":").append(mMinute);
		return sblTmp.toString();
	}

	public String makeDateTimeString(int mDay, int mMonth, int mYear,
			int mHour, int mMinute, String AMPM) {

		if (mHour > 12) {
			mHour = mHour - 12;
			AMPM = "PM";
		} else {
			if (mHour == 12) {
				AMPM = "PM";
			} else {
				AMPM = "AM";
			}
		}
		String Minute = String.valueOf(mMinute);
		if (mMinute < 10) {
			Minute = "0" + String.valueOf(mMinute);
		}
		StringBuilder sblTmp = new StringBuilder()
				// Month is 0 based so add 1
				.append(mDay).append("-").append(mMonth + 1).append("-")
				.append(mYear).append(" ").append(mHour).append(":")
				.append(Minute).append(" ").append(AMPM);
		return sblTmp.toString();

	}

	public String makeSQLDateString(int mDay, int mMonth, int mYear) {

		StringBuilder sblTmp = new StringBuilder()
				// Month is 0 based so add 1
				.append(mYear).append("-").append(mMonth + 1).append("-")
				.append(mDay);
		return sblTmp.toString();

	}

	public String makeDateTimeStringYearFirst(int mDay, int mMonth, int mYear,
			int mHour, int mMinute, String AMPM) {

		if (mHour > 12) {
			mHour = mHour - 12;
			AMPM = "PM";
		} else {
			if (mHour == 12) {
				AMPM = "PM";
			} else {
				AMPM = "AM";
			}
		}
		String Minute = String.valueOf(mMinute);
		if (mMinute < 10) {
			Minute = "0" + String.valueOf(mMinute);
		}
		StringBuilder sblTmp = new StringBuilder()
				// Month is 0 based so add 1
				.append(mYear).append("-").append(mMonth + 1).append("-")
				.append(mDay).append(" ").append(mHour).append(":")
				.append(Minute).append(" ").append(AMPM);
		return sblTmp.toString();

	}

	public void ShowAlert(Context context, String msg) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(msg).setCancelable(true)
				.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});
		AlertDialog alert = builder.create();
		try {
			alert.show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void ShowAlertAndFinish(Context context, String msg,
			final Activity activity) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(msg).setCancelable(false)
				.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						activity.finish();
					}
				});
		AlertDialog alert = builder.create();
		try {
			alert.show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String DateTimetoString(Date oDate) {
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aa");
		String strDate = formatter.format(oDate);
		return strDate;
	}

	public String DateToString(Date oDate) {
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(oDate);
		return strDate;
	}

	public void ShowNoInternet(final Context context, final Activity activity) {
		activity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(context);
				builder.setMessage(NOINTERNET)
						.setCancelable(false)
						.setPositiveButton("OK",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int id) {
										activity.finish();
									}
								});
				AlertDialog alert = builder.create();
				try {
					alert.show();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});

	}

	public void ShowNoInternetWithoutClosing(final Context context,
			final Activity activity) {
		activity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(context);
				builder.setMessage(NOINTERNET)
						.setCancelable(false)
						.setPositiveButton("OK",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int id) {
										// activity.finish();
									}
								});
				AlertDialog alert = builder.create();
				try {
					alert.show();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});

	}

	public void callPhone(final String PhoneNo, final Activity activity,
			Context context) {

		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("Want to call : " + PhoneNo)
				.setCancelable(true)
				.setPositiveButton("Yes",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								try {
									Intent callIntent = new Intent(
											Intent.ACTION_CALL);
									callIntent.setData(Uri.parse("tel:"
											+ PhoneNo));
									activity.startActivity(callIntent);
								} catch (ActivityNotFoundException activityException) {
									Log.e("DishMagic", "Call failed",
											activityException);
								}
							}
						})
				.setNegativeButton("No", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
					}
				});
		AlertDialog alert = builder.create();
		try {
			alert.show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public String CurrentDateTimetoString() {
		final Calendar c = Calendar.getInstance();
		int hour = c.get(Calendar.HOUR);

		if (c.get(Calendar.AM_PM) == 1) {
			hour = hour + 12;
		}

		StringBuilder sblTmp = new StringBuilder()
				// Month is 0 based so add 1
				.append(c.get(Calendar.YEAR)).append("-")
				.append(c.get(Calendar.MONTH) + 1).append("-")
				.append(c.get(Calendar.DATE)).append(" ").append(hour)
				.append(":").append(c.get(Calendar.MINUTE)).append(":")
				.append(c.get(Calendar.SECOND)).append(" ");
		return sblTmp.toString();
	}

	public String CurrentDateTimeMinusDaystoString(int days) {
		final Calendar c = Calendar.getInstance();
		long l = c.getTimeInMillis() - days * 24 * 60 * 60 * 1000;
		c.setTimeInMillis(l);
		int hour = c.get(Calendar.HOUR);

		if (c.get(Calendar.AM_PM) == 1) {
			hour = hour + 12;
		}

		StringBuilder sblTmp = new StringBuilder()
				// Month is 0 based so add 1
				.append(c.get(Calendar.YEAR)).append("-")
				.append(c.get(Calendar.MONTH) + 1).append("-")
				.append(c.get(Calendar.DATE)).append(" ").append(hour)
				.append(":").append(c.get(Calendar.MINUTE)).append(":")
				.append(c.get(Calendar.SECOND)).append("");
		return sblTmp.toString();
	}

	public Boolean CurrentDateTimeDifference(String strDateTime) {
		Boolean isDifferent;
		isDifferent = false;

		try {
			long acceptableDifference = 1 * 60 * 60 * 1000;
			final Calendar c = Calendar.getInstance();
			Date c2;
			long localTime = c.getTimeInMillis();
			c2 = new Date(Integer.parseInt(strDateTime.substring(4, 8)) - 1900,
					Integer.parseInt(strDateTime.substring(0, 2)) - 1,
					Integer.parseInt(strDateTime.substring(2, 4)),
					Integer.parseInt(strDateTime.substring(8, 10)),
					Integer.parseInt(strDateTime.substring(10, 12)),
					Integer.parseInt(strDateTime.substring(12, 14)));
			long inTime = c2.getTime();

			if ((localTime > (inTime - acceptableDifference) && localTime < (inTime + acceptableDifference))
					|| (localTime == inTime))
				isDifferent = false;
			else
				isDifferent = true;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			isDifferent = false;
		}
		return isDifferent;
	}

	public boolean DateComparewithStringDate(String strDate, int days) {
		try {

			SimpleDateFormat curFormater = new SimpleDateFormat("yyyy-MM-dd");
			Date dateObj = curFormater.parse(strDate);
			Calendar thatDay = Calendar.getInstance();
			thatDay.set(Calendar.DAY_OF_MONTH, dateObj.getDate());
			thatDay.set(Calendar.MONTH, dateObj.getMonth()); // 0-11 so 1 less
			thatDay.set(Calendar.YEAR, dateObj.getYear() + 1900);

			Calendar today = Calendar.getInstance();

			long diff = today.getTimeInMillis() - thatDay.getTimeInMillis();

			if (diff > (days * 24 * 60 * 60 * 1000))
				return true;
			else
				return false;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public String sqldatetoMMDDYYYYandtime(String date)
	{
		StringBuilder sblTmp = new StringBuilder();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date d = sdf.parse(date);
			
		
			// Month is 0 based so add 1
			sblTmp.append(String.format("%02d", d.getMonth() + 1)).append("/").append(String.format("%02d", d.getDate())).append("/")
			.append(d.getYear()+1900).append(" ").append(String.format("%02d", d.getHours())).append(":")
			.append(String.format("%02d", d.getMinutes())).append(":").append(String.format("%02d", d.getSeconds()));

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sblTmp.toString();

	}

	public static double round(BigDecimal bd, int precision, int roundingMode) {
		BigDecimal rounded = bd.setScale(precision, roundingMode);
		return rounded.doubleValue();
	}

	public void setSharedPreferencesValue(Context context, String Name,
			String Value) {
		SharedPreferences myPrefs = context.getSharedPreferences(
				"SignCatchmerchant", context.MODE_WORLD_READABLE);
		SharedPreferences.Editor prefsEditor = myPrefs.edit();
		prefsEditor.putString(Name, Value);
		prefsEditor.commit();
	}

	public String getSharedPreferencesValue(Context context, String Name) {

		try {
			SharedPreferences myPrefs = context.getSharedPreferences(
					"SignCatchmerchant", context.MODE_WORLD_READABLE);
			return myPrefs.getString(Name, "");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}

	}

	public String getIMEI(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		return telephonyManager.getDeviceId().toString();
	}

	public static Bitmap getBitmapFromURL(String src) {
		try {
			Log.e("src", src);
			URL url = new URL(src);
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoInput(true);
			connection.connect();
			InputStream input = connection.getInputStream();
			Bitmap myBitmap = BitmapFactory.decodeStream(input);
			Log.e("Bitmap", "returned");
			return myBitmap;
		} catch (IOException e) {
			e.printStackTrace();
			Log.e("Exception", e.getMessage());
			return null;
		}
	}
}
