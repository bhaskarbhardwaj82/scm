package com.signcatch.merchant;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import android.content.Context;
import android.graphics.Path;
import android.widget.Toast;

public class clsFileHandle {
	private String strFileName="/REG_KEY.TXT";
	
	   public Boolean WriteText(String strText)
	   {
		   Boolean bolReturnValue=false;
		   try 
		   {
			   FileWriter outFile = new FileWriter(strFileName);
	           PrintWriter out = new PrintWriter(outFile);
	           out.println(strText);
	           out.close();
	           bolReturnValue=true;
		   } 
		   catch (IOException e)
		   {
			   e.printStackTrace();
			   bolReturnValue=false;
		   }
		   return bolReturnValue;
	  }
	   
	   
	   public String ReadTextFile()
	   { 
		   File file = new File(strFileName); 
		   StringBuffer contents = new StringBuffer(); 
		   BufferedReader reader = null; 
		    
		   try
		   { 
			   reader = new BufferedReader(new FileReader(file)); 
			   String text = null; 
			   // repeat until all lines is read 
			   while ((text = reader.readLine()) != null) 
			   { 
				   contents.append(text).append(System.getProperty("line.separator")); 
			   } 
		   } 
		   catch (FileNotFoundException e) 
		   { 
			   e.printStackTrace(); 
		   } 
		   catch (IOException e) 
		   { 
			   e.printStackTrace(); 
		   } 
		   finally
		   { 
			   try
			   { 
				   if (reader != null) 
				   { 
					   reader.close(); 
				   } 
			   } 
			   catch (IOException e) 
			   {
				   e.printStackTrace(); 
			   } 
		   } 
		   return contents.toString();
	   } 
	   public void WritetoFile(String string,String FileName, Context context)
	   {
	       try 
	       { 
	    	   if (FileExist(FileName,context))
	    	   {
	    		   FileDelete(FileName, context);
	    	   }
	           FileOutputStream fOut = context.openFileOutput(FileName, context.MODE_WORLD_WRITEABLE);
	           OutputStreamWriter osw = new OutputStreamWriter(fOut);  
	           osw.write(string);
	           osw.flush();
	           osw.close();
	       }
	       catch (Exception ex) {}
	   }
	   public String ReadSpecificFile(String FileName,Context context)
	   {   
		   if (FileExist(FileName, context))
		   {
			   	int i;
			   	ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();          
			   	try 
			   	{   
			   		InputStream inputStream = context.openFileInput(FileName);
			       		i = inputStream.read();   
			   		while (i != -1)      
			   		{       
			   			byteArrayOutputStream.write(i);       
			   			i = inputStream.read();      
			   		}      
			   		inputStream.close();  
			   	} 
			   	catch (IOException e) 
			   	{      
			   		e.printStackTrace();  
			   		byteArrayOutputStream.write(32);
			   	}       
			   	
			   	return byteArrayOutputStream.toString();  
		   }
		   else
		   {
			   return "";
		   }
	   }
	   
	   public static Boolean FileDelete(String filename,  Context context)
	   {
		   boolean success = context.deleteFile(filename);
		   return success;
	   }
	   
	   public static Boolean FileExist(String filename, Context context)
	   {
		   	String[] filenames = context.fileList();         
		   for (String name : filenames) 
		   {           
			   if (name.equals(filename)) 
			   {             
				   return true;           
				            
			   }          
		   }
		   return false;
	   }


	
}
