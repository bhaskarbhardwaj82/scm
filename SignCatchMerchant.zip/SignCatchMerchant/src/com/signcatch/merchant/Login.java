package com.signcatch.merchant;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.signcatch.merchant.*;

public class Login extends Activity {
	// init start
	private clsGeneral objGeneral;
	private Runnable runnable;
	Boolean running = false;
	Handler h = new Handler();
	Context mContext;
	Activity mActivity;
	// //init close

	EditText txtUserName;
	EditText txtPassword;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		init();
		txtUserName = (EditText) findViewById(R.id.txtUserName);
		txtPassword = (EditText) findViewById(R.id.txtPassword);

		txtUserName.setText(objGeneral.getSharedPreferencesValue(
				getApplicationContext(), "UserID"));

		Button btnClose = (Button) findViewById(R.id.btnClose);
		btnClose.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});

		Button btnLogin = (Button) findViewById(R.id.btnLogin);
		btnLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				if (txtUserName.getText().toString().length() > 0
						&& txtPassword.getText().toString().length() > 0) {
					Thread t = new Thread(new Runnable() {

						@Override
						public void run() {

							running = true;
							h.post(runnable);

							CallWebMethods oCallWebMethods = new CallWebMethods();
							String returnValue = oCallWebMethods.ValidateUser(
									mContext, txtUserName.getText().toString(),
									txtPassword.getText().toString());

							if (returnValue == null) {
								runOnUiThread(new Runnable() {
									public void run() {
										objGeneral.ShowAlert(mContext,
												objGeneral.NOINTERNET);
									}
								});
							} else if (returnValue
									.equals(objGeneral.NOINTERNET)) {
								runOnUiThread(new Runnable() {
									public void run() {
										objGeneral.ShowAlert(mContext,
												objGeneral.NOINTERNET);
									}
								});
							} else {
								if (returnValue.split("~")[0].toString()
										.equals("0")) {
									final String tmpVal = returnValue
											.split("~")[1].toString();
									runOnUiThread(new Runnable() {
										public void run() {
											objGeneral.ShowAlert(mContext,
													tmpVal);
										}
									});
								} else {
									runOnUiThread(new Runnable() {
										public void run() {
											// objGeneral.ShowAlertAndFinish(context,
											// msg,
											// activity)(mContext,"Successfully Loggedin"
											// );
											objGeneral
													.setSharedPreferencesValue(
															getApplicationContext(),
															"UserID",
															txtUserName
																	.getText()
																	.toString());

											Intent ittDashboard = new Intent(
													mContext, DashBoard.class);
											startActivity(ittDashboard);
											finish();
										}
									});

								}
							}
							running = false;
							h.post(runnable);
						}
					});
					t.start();
				}
			}
		});
	}

	private void init() {
		objGeneral = new clsGeneral();
		objGeneral.InitLoadPopup(this,
				(ViewGroup) findViewById(R.id.layout_root));
		mContext = Login.this;
		mActivity = Login.this;
		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}
}