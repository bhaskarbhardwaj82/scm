package com.signcatch.merchant;

import static com.signcatch.merchant.CommonUtilities.EXTRA_MESSAGE;
import static com.signcatch.merchant.CommonUtilities.DISPLAY_MESSAGE_ACTION;
import static com.signcatch.merchant.CommonUtilities.SENDER_ID;
import static com.signcatch.merchant.CommonUtilities.SERVER_URL;

import com.google.android.gcm.GCMRegistrar;
import com.signcatch.merchant.R;
import com.signcatch.merchant.ServerUtilities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AddProduct extends Activity {
	// init start
	private clsGeneral objGeneral = new clsGeneral();
	private Runnable runnable;
	Boolean running = false;
	Handler h = new Handler();
	Context mContext;
	Activity mActivity;
	// //init close

	EditText txtProductName;
	EditText txtProductDesc;
	EditText txtAmount;

	LinearLayout llaProductName;
	LinearLayout llaProductDesc;
	Boolean showSignCatch = false;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addproduct);
		init();
		
		txtProductName = (EditText) findViewById(R.id.txtProductName);
		txtProductDesc = (EditText) findViewById(R.id.txtProductDesc);
		txtAmount = (EditText) findViewById(R.id.txtAmount);

		llaProductName = (LinearLayout) findViewById(R.id.llaProductName);
		llaProductDesc = (LinearLayout) findViewById(R.id.llaProductDesc);
		updateUI();
		Button btnCash = (Button) findViewById(R.id.btnCash);
		btnCash.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				Thread t = new Thread(new Runnable() {

					@Override
					public void run() {

						running = true;
						h.post(runnable);

						String ProductName= txtProductName.getText().toString().trim();
						if(ProductName.length()==0)
						{
							ProductName = "General Sale";
						}
						
						CallWebMethods oCallWebMethods = new CallWebMethods();

						String returnValue = oCallWebMethods.AddCash(
								mContext, objGeneral.getSharedPreferencesValue(
										getApplicationContext(), "UserID"),
										ProductName,
								txtProductDesc.getText().toString(), txtAmount
										.getText().toString(), "", objGeneral
										.getSharedPreferencesValue(
												getApplicationContext(),
												"DeviceID"));

						if (returnValue == null) {
							runOnUiThread(new Runnable() {
								public void run() {
									objGeneral.ShowAlert(mContext,
											objGeneral.NOINTERNET);
								}
							});
						} else if (returnValue.equals(objGeneral.NOINTERNET)) {
							runOnUiThread(new Runnable() {
								public void run() {
									objGeneral.ShowAlert(mContext,
											objGeneral.NOINTERNET);
								}
							});
						} else {
							if (returnValue.split("~")[0].toString()
									.equals("0")) {
								final String tmpVal = returnValue.split("~")[1]
										.toString();
								runOnUiThread(new Runnable() {
									public void run() {
										objGeneral.ShowAlert(mContext, tmpVal);
									}
								});
							} else {
								final String tmpVal = returnValue.split("~")[1]
										.toString();
								final String tmpPoints = returnValue.split("~")[1]
								        										.toString();
								final String tmpImgLnk = returnValue.split("~")[2]
								        										.toString();
								final String tmpDesc = returnValue.split("~")[4]
								        										.toString();

								if (showSignCatch) {
									objGeneral.setSharedPreferencesValue(
											getApplicationContext(),
											"ImageURL", tmpImgLnk);
									objGeneral.setSharedPreferencesValue(
											getApplicationContext(),
											"DETAILS", tmpDesc);
									Intent ittDisplaySignCatch = new Intent(
											mContext, DisplaySignCatch.class);
									startActivity(ittDisplaySignCatch);

								} else {
									runOnUiThread(new Runnable() {
										public void run() {
											objGeneral.ShowAlert(mContext,
													"Generated, Please ask user to scan and get points");
										}
									});
								}
							}
						}
						running = false;
						h.post(runnable);
					}
				});
				t.start();
			}
		});

		Button btnGenerate = (Button) findViewById(R.id.btnGenerate);
		btnGenerate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Thread t = new Thread(new Runnable() {

					@Override
					public void run() {

						running = true;
						h.post(runnable);

						String ProductName= txtProductName.getText().toString().trim();
						if(ProductName.length()==0)
						{
							ProductName = "General Sale";
						}
						
						CallWebMethods oCallWebMethods = new CallWebMethods();

						String returnValue = oCallWebMethods.AddProduct(
								mContext, objGeneral.getSharedPreferencesValue(
										getApplicationContext(), "UserID"),
										ProductName,
								txtProductDesc.getText().toString(), txtAmount
										.getText().toString(), "", objGeneral
										.getSharedPreferencesValue(
												getApplicationContext(),
												"DeviceID"));

						if (returnValue == null) {
							runOnUiThread(new Runnable() {
								public void run() {
									objGeneral.ShowAlert(mContext,
											objGeneral.NOINTERNET);
								}
							});
						} else if (returnValue.equals(objGeneral.NOINTERNET)) {
							runOnUiThread(new Runnable() {
								public void run() {
									objGeneral.ShowAlert(mContext,
											objGeneral.NOINTERNET);
								}
							});
						} else {
							if (returnValue.split("~")[0].toString()
									.equals("0")) {
								final String tmpVal = returnValue.split("~")[1]
										.toString();
								runOnUiThread(new Runnable() {
									public void run() {
										objGeneral.ShowAlert(mContext, tmpVal);
									}
								});
							} else {
								final String tmpVal = returnValue.split("~")[1]
										.toString();
								final String tmpImgLnk = returnValue.split("~")[2]
								        										.toString();
								final String tmpDesc = returnValue.split("~")[4]
								        										.toString();

								if (showSignCatch) {
									objGeneral.setSharedPreferencesValue(
											getApplicationContext(),
											"ImageURL", tmpImgLnk);
									objGeneral.setSharedPreferencesValue(
											getApplicationContext(),
											"DETAILS", tmpDesc);
									Intent ittDisplaySignCatch = new Intent(
											mContext, DisplaySignCatch.class);
									startActivity(ittDisplaySignCatch);

								} else {
									runOnUiThread(new Runnable() {
										public void run() {
											objGeneral.ShowAlert(mContext,
													tmpVal);
										}
									});
								}
							}
						}
						running = false;
						h.post(runnable);
					}
				});
				t.start();
			}
		});
	}

	private void init() {
		objGeneral = new clsGeneral();
		objGeneral.InitLoadPopup(this,
				(ViewGroup) findViewById(R.id.layout_root));
		mContext = AddProduct.this;
		mActivity = AddProduct.this;
		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}

	protected void onResume() {
		super.onResume();
		updateUI();

		// if(objGeneral.getSharedPreferencesValue(getApplicationContext(),
		// "PUSHNOTIFICATION").equals("1"))
		// {
		// CheckAndRegisterPushNotification();
		// }else
		// if(objGeneral.getSharedPreferencesValue(getApplicationContext(),
		// "PUSHNOTIFICATION").equals("0"))
		// {
		// if (mRegisterTask != null) {
		// mRegisterTask.cancel(true);
		// }
		// try{
		// unregisterReceiver(mHandleMessageReceiver);
		// GCMRegistrar.onDestroy(this);
		// }catch (Exception e) {
		// // TODO: handle exception
		// }
		//
		// }

	}

	private void updateUI() {
		if (objGeneral.getSharedPreferencesValue(getApplicationContext(),
				"ShowProductInfo").equals("0")) {
			llaProductName.setVisibility(View.GONE);
			llaProductDesc.setVisibility(View.GONE);
			txtProductName.setText("");
			txtProductDesc.setText("");
		} else {
			llaProductName.setVisibility(View.VISIBLE);
			llaProductDesc.setVisibility(View.VISIBLE);
		}

		if (objGeneral.getSharedPreferencesValue(getApplicationContext(),
				"ShowSignCatch").equals("0")) {
			showSignCatch = false;
		} else {
			showSignCatch = true;
		}
	}

	public boolean onPrepareOptionsMenu(Menu menu) {
		MakeMenu(menu);
		return true;
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		MakeMenu(menu);
		return true;
	}

	private void MakeMenu(Menu menu) {
		menu.clear();
//		MenuInflater inflater = getMenuInflater();
//		menu.add("Settings");
//		menu.add("My Device ID");
//		menu.add("SignCatch Display");
//		menu.add("Transactions");
//		inflater.inflate(R.menu.menu, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		String value = item.getTitle().toString();
		if (value.equals("Settings")) {
			Intent ittSettings = new Intent(mContext, Settings.class);
			startActivity(ittSettings);
		} else if (value.equals("My Device ID")) {
			objGeneral.ShowAlert(mContext,
					"My Device ID : " + objGeneral.getIMEI(mContext));
		} else if (value.equals("SignCatch Display")) {
			Intent ittAutoShowSignCatch = new Intent(mContext,
					AutoShowSignCatch.class);
			startActivity(ittAutoShowSignCatch);
		}else if (value.equals("Transactions")) {
			Intent ittTransactions = new Intent(mContext,
					History.class);
			startActivity(ittTransactions);
		}
		return true;
	}

	

}