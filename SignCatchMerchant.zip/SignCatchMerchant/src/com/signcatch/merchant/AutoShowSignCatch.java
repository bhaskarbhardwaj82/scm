
package com.signcatch.merchant;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AutoShowSignCatch extends Activity {
	// init start
	private clsGeneral objGeneral = new clsGeneral();
	private Runnable runnable;
	Boolean running = false;
	Handler h = new Handler();
	CallWebMethods oCallWebMethods = new CallWebMethods();
	Context mContext;
	Activity mActivity;
	// //init close
	Boolean isAlertShowing = false;
	int displayHeight = 0;
	int displayWidth = 0;

	int displaySize = 0;
	ImageView imgQRCode;
	LinearLayout llaQRCode;
	TextView lblDetails, lblHeader;

	String ImageLink = "";

	String productname;
	String product_desc;
	String price;
	String signcatch_full_url = "";
	Bitmap bimage;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		try {
			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			this.getWindow().setFlags(
					WindowManager.LayoutParams.FLAG_FULLSCREEN,
					WindowManager.LayoutParams.FLAG_FULLSCREEN);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setContentView(R.layout.dispaysigncatch);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		mContext = this;
		mActivity = this;
		imgQRCode = (ImageView) findViewById(R.id.imgQRCode);
		llaQRCode = (LinearLayout) findViewById(R.id.llaQRCode);
		lblDetails = (TextView) findViewById(R.id.lblDetails);
		lblHeader = (TextView) findViewById(R.id.lblHeader);
		// Bitmap bimage = objGeneral
		// .getBitmapFromURL(objGeneral.getSharedPreferencesValue(
		// getApplicationContext(), "ImageURL"));

		Timer timer = new Timer();
		TimerTask updateSignCatch = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				String returnValue = oCallWebMethods.getDeviceProduct(mContext,
						objGeneral.getIMEI(mContext));

				if (returnValue == null) {
					runOnUiThread(new Runnable() {
						public void run() {
							ShowAlertOnlyOnce(mContext, objGeneral.NOINTERNET);
						}
					});
				} else if (returnValue.equals(objGeneral.NOINTERNET)) {
					runOnUiThread(new Runnable() {
						public void run() {
							ShowAlertOnlyOnce(mContext, objGeneral.NOINTERNET);
						}
					});
				} else {
					if (returnValue.split("~")[0].toString().equals("0")) {
						final String tmpVal = returnValue.split("~")[1]
								.toString();
						runOnUiThread(new Runnable() {
							public void run() {
								// ShowAlertOnlyOnce(mContext, tmpVal);
								llaQRCode
										.setBackgroundResource(R.drawable.blank);
								imgQRCode.setImageResource(R.drawable.logo);
								lblDetails.setText("");
							}
						});

					} else {
						if (signcatch_full_url.equals(returnValue.split("~")[5]
								.toString()) == false) {
							productname = returnValue.split("~")[1].toString();
							product_desc = returnValue.split("~")[3].toString();
							;
							price = returnValue.split("~")[4].toString();
							;
							signcatch_full_url = returnValue.split("~")[5]
									.toString();
							bimage = objGeneral
									.getBitmapFromURL(signcatch_full_url);
							runOnUiThread(new Runnable() {
								public void run() {
									imgQRCode.setImageBitmap(bimage);
									if(price.contains("Points"))
									{
										lblHeader.setText("Scan to get points");
									}else
									{
										lblHeader.setText("Scan to pay");
									}
									if (productname.length() > 0) {
										lblDetails.setText(price + ", "
												+ productname);
									} else
										lblDetails.setText(price);
									llaQRCode
											.setBackgroundResource(R.drawable.signcatch600new);
								}
							});
							updateUI();
						}
					}
				}
			}
		};
		timer.scheduleAtFixedRate(updateSignCatch, 2000, 6000);

		// imgQRCode.setImageBitmap(bimage);

		// updateUI();

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);

		updateUI();
	}

	private void init() {
		objGeneral.InitLoadPopup(mContext,
				(ViewGroup) findViewById(R.id.layout_root));
		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}

	private void updateUI() {

		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				displaySize = 0;
				if (getResources().getDisplayMetrics().widthPixels > getResources()
						.getDisplayMetrics().heightPixels) {
					llaQRCode
							.setLayoutParams(new LinearLayout.LayoutParams(
									getWindowManager().getDefaultDisplay()
											.getHeight() - 100,
									getWindowManager().getDefaultDisplay()
											.getHeight() - 100));
					// Integer imageSize =
					// Integer.valueOf(String.valueOf((getWindowManager().getDefaultDisplay().getHeight()-100)*0.596));
					int imageSize = (int) ((getWindowManager()
							.getDefaultDisplay().getHeight() - 120) * 0.58);
					imgQRCode.setLayoutParams(new LinearLayout.LayoutParams(
							imageSize, imageSize));

				} else {
					llaQRCode
							.setLayoutParams(new LinearLayout.LayoutParams(
									getWindowManager().getDefaultDisplay()
											.getWidth() - 100,
									getWindowManager().getDefaultDisplay()
											.getWidth() - 100));
					int imageSize = (int) ((getWindowManager()
							.getDefaultDisplay().getWidth() - 120) * 0.58);
					imgQRCode.setLayoutParams(new LinearLayout.LayoutParams(
							imageSize, imageSize));

				}
			}
		});

	}

	public void ShowAlertOnlyOnce(Context context, String msg) {
		if (isAlertShowing == false) {
			isAlertShowing = true;
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setMessage(msg)
					.setCancelable(true)
					.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									isAlertShowing = false;
									dialog.cancel();
								}
							});
			AlertDialog alert = builder.create();
			try {
				alert.show();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	public boolean onPrepareOptionsMenu(Menu menu) {
		MakeMenu(menu);
		return true;
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		MakeMenu(menu);
		return true;
	}

	private void MakeMenu(Menu menu) {
		menu.clear();
		MenuInflater inflater = getMenuInflater();
		menu.add("Close");
		inflater.inflate(R.menu.menu, menu);
	}

	private void stopForceScreenOn() {
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		String value = item.getTitle().toString();
		if (value.equals("Close")) {
			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			builder.setMessage("Do you want to close?")
					.setCancelable(false)
					.setNegativeButton("No",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface arg0,
										int arg1) {
									arg0.dismiss();
								}
							})
					.setPositiveButton("Yes",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mActivity.finish();
								}
							});
			AlertDialog alert = builder.create();
			try {
				alert.show();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}
		return true;
	}
}