package com.signcatch.merchant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DisplaySignCatch extends Activity {
	// init start
	private clsGeneral objGeneral = new clsGeneral();
	private Runnable runnable;
	Boolean running = false;
	Handler h = new Handler();
	Context mContext;
	Activity mActivity;
	// //init close
	int displayHeight = 0;
	int displayWidth = 0;

	int displaySize = 0;
	ImageView imgQRCode;
	LinearLayout llaQRCode;
	TextView lblDetails,lblHeader;
	String ImageLink = "";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		try {
			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setContentView(R.layout.dispaysigncatch);
		mContext = this;
		mActivity = this;
		imgQRCode = (ImageView) findViewById(R.id.imgQRCode);
		llaQRCode = (LinearLayout) findViewById(R.id.llaQRCode);
		llaQRCode.setBackgroundResource(R.drawable.signcatch600new);
		lblDetails = (TextView) findViewById(R.id.lblDetails);
		lblHeader = (TextView) findViewById(R.id.lblHeader);
//		objGeneral.setSharedPreferencesValue(
//				getApplicationContext(),
//				"ImageURL", tmpImgLnk);
//		objGeneral.setSharedPreferencesValue(
//				getApplicationContext(),
//				"PointsGiven", tmpPoints);
//		objGeneral.setSharedPreferencesValue(
//				getApplicationContext(),
//				"Type", "CASH");
//		
//		
		if(objGeneral.getSharedPreferencesValue(
				getApplicationContext(), "DETAILS").contains("Points"))
		{
			lblHeader.setText("Scan to get points");
		}else
		{
			lblHeader.setText("Scan to pay");
		}
		lblDetails.setText( objGeneral.getSharedPreferencesValue(
						getApplicationContext(), "DETAILS"));
		Bitmap bimage = objGeneral
				.getBitmapFromURL(objGeneral.getSharedPreferencesValue(
						getApplicationContext(), "ImageURL"));
		imgQRCode.setImageBitmap(bimage);

		updateUI();
//		Button btnClose = (Button) findViewById(R.id.btnClose);
//		btnClose.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
//				builder.setMessage("Do you want to close?")
//						.setCancelable(false)
//						.setNegativeButton("No",
//								new DialogInterface.OnClickListener() {
//
//									@Override
//									public void onClick(DialogInterface arg0,
//											int arg1) {
//										arg0.dismiss();
//									}
//								})
//						.setPositiveButton("Yes",
//								new DialogInterface.OnClickListener() {
//									public void onClick(DialogInterface dialog,
//											int id) {
//										mActivity.finish();
//									}
//								});
//				AlertDialog alert = builder.create();
//				try {
//					alert.show();
//				} catch (Exception ex) {
//					ex.printStackTrace();
//				}
//
//			}
//		});
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);

		// if (getResources().getDisplayMetrics().widthPixels > getResources()
		// .getDisplayMetrics().heightPixels) {
		// // Toast t = Toast.makeText(this,"LANDSCAPE",Toast.LENGTH_SHORT);
		// // t.show();
		// // return 1;
		// } else {
		// // Toast t = Toast.makeText(this,"PORTRAIT",Toast.LENGTH_SHORT);
		// // t.show();
		// // return 2;
		// }

		updateUI();
	}

	private void updateUI() {

		displaySize = 0;
		if (getResources().getDisplayMetrics().widthPixels > getResources()
				.getDisplayMetrics().heightPixels) {
			llaQRCode.setLayoutParams(new LinearLayout.LayoutParams(getWindowManager().getDefaultDisplay().getHeight()-100,getWindowManager().getDefaultDisplay().getHeight()-100));
			//Integer imageSize = Integer.valueOf(String.valueOf((getWindowManager().getDefaultDisplay().getHeight()-100)*0.596));
			int imageSize = (int)((getWindowManager().getDefaultDisplay().getHeight()-120)*0.58);
			imgQRCode.setLayoutParams(new LinearLayout.LayoutParams(imageSize,imageSize));
			
		} else {
			llaQRCode.setLayoutParams(new LinearLayout.LayoutParams(getWindowManager().getDefaultDisplay().getWidth()-100,getWindowManager().getDefaultDisplay().getWidth()-100));
			int imageSize = (int)((getWindowManager().getDefaultDisplay().getWidth()-120)*0.58);
			imgQRCode.setLayoutParams(new LinearLayout.LayoutParams(imageSize,imageSize));
			
		}
		
		
		
	}
	public boolean onPrepareOptionsMenu(Menu menu) {
		MakeMenu(menu);
		return true;
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		MakeMenu(menu);
		return true;
	}

	private void MakeMenu(Menu menu) {
		menu.clear();
		MenuInflater inflater = getMenuInflater();
		menu.add("Close");
		inflater.inflate(R.menu.menu, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		String value = item.getTitle().toString();
		if (value.equals("Close")) {
			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			builder.setMessage("Do you want to close?")
					.setCancelable(false)
					.setNegativeButton("No",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface arg0,
										int arg1) {
									arg0.dismiss();
								}
							})
					.setPositiveButton("Yes",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mActivity.finish();
								}
							});
			AlertDialog alert = builder.create();
			try {
				alert.show();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}
		return true;
	}
}