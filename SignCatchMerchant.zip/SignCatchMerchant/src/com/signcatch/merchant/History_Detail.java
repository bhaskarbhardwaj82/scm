package com.signcatch.merchant;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;



public class History_Detail extends Activity {
	String inputData;
	JSONObject row;
	TextView tviProductName, tvCustomerNameData, tvAmountData, tviTranDate;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history_detail);

		
		getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

		Bundle bundle = getIntent().getExtras();
		inputData = bundle.getString("ROWDATA");
		
		try {
			row = new JSONObject(inputData);

			tviProductName = (TextView) findViewById(R.id.tviProductName);
			tvCustomerNameData = (TextView) findViewById(R.id.tvCustomerNameData);
			
			tvAmountData = (TextView) findViewById(R.id.tvAmountData);
			tviTranDate = (TextView) findViewById(R.id.tviDate);

			String amnt = "$" + row.getString("Price");
			
			tviProductName.setText(row.getString("ProductName"));
			tvCustomerNameData.setText(row.getString("CustomerName"));
			//tviDiscription.setText(allValue[12].toString());
			//tviMerchantName.setText(allValue[13].toString());
			//tviCardNo.setText(allValue[10].toString());
			tvAmountData.setText(amnt);
			tviTranDate.setText(row.getString("TransactionDate"));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
