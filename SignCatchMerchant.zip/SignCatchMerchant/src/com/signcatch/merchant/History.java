package com.signcatch.merchant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class History extends Activity {
	String inputData;
	// String[] allRows;
	ListView lstHistory;
	TextView tviDateTitle;
	private clsGeneral objGeneral;
	private Runnable runnable;
	Boolean running = false;
	private Handler handler = new Handler();
	Handler h = new Handler();
	Context mContext;
	Activity mActivity;
	String userName;
	// ImageButton imbNext;
	JSONArray alldata;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history);
		init();
		String userid = objGeneral.getSharedPreferencesValue(
				getApplicationContext(), "UserID");
		if (userid.length() > 0) {
			
			getHistoryData();
		} else {
			Intent ittLogin = new Intent(History.this,
					Login.class);
			History.this.startActivity(ittLogin);
			finish();
		}

	}

	private void getHistoryData() {
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {

				running = true;
				h.post(runnable);

				CallWebMethods oCallWebMethods = new CallWebMethods();

				final Object returnValue = oCallWebMethods.TransectionHistory(
						mContext, objGeneral.getSharedPreferencesValue(
								getApplicationContext(), "UserID"), 0, 30);

				if (returnValue == null) {
					runOnUiThread(new Runnable() {
						public void run() {

							objGeneral.ShowAlert(mContext,
									objGeneral.NOINTERNET);
						}
					});

				} else if (returnValue.equals(objGeneral.NOINTERNET)) {
					runOnUiThread(new Runnable() {
						public void run() {

							objGeneral.ShowAlert(mContext,
									objGeneral.NOINTERNET);
						}
					});

				} else {
					if (returnValue.toString().split("~")[0].equals("0")) {
						final String tmpVal = returnValue.toString().split("~")[1];

						runOnUiThread(new Runnable() {
							public void run() {

								objGeneral.ShowAlert(mContext, tmpVal);

							}
						});
					} else {
						runOnUiThread(new Runnable() {
							public void run() {
								try {

									inputData = returnValue.toString();
									bindGrid();
									
									objGeneral.setSharedPreferencesValue(getApplicationContext(), "PushMessageCount", "0");
									
								} catch (Exception ex) {
									String s = "";
								}

							}
						});

					}

				}
				running = false;
				h.post(runnable);
			}
		});
		t.start();
	}

	private void init() {
		objGeneral = new clsGeneral();
		objGeneral.InitLoadPopup(this,
				(ViewGroup) findViewById(R.id.layout_root));
		mContext = History.this;
		mActivity = History.this;
		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}

	private void bindGrid() {

		try {
			alldata = new JSONArray(inputData);

			lstHistory = (ListView) findViewById(R.id.lstHistory);
			tviDateTitle = (TextView) findViewById(R.id.tviDateTime);
			tviDateTitle.setText("Date & Time");

			String[] from = new String[] { "DateTime", "Name", "Amount" };
			int[] to = new int[] { R.id.tviDateTime, R.id.tviProductName,
					R.id.tviAmount };

			List<HashMap<String, String>> fillMaps = new ArrayList<HashMap<String, String>>();
			for (int i = 0; i < alldata.length(); i++) {
				HashMap<String, String> map = new HashMap<String, String>();
				JSONObject row = alldata.getJSONObject(i);
				map.put("DateTime", objGeneral.sqldatetoMMDDYYYYandtime(row.getString("TransactionDate")));
				map.put("Name", row.getString("ProductName"));
				map.put("Amount", row.getString("Price"));

				fillMaps.add(map);
			}
			SimpleAdapter adapter = new SimpleAdapter(History.this, fillMaps,
					R.layout.history_list, from, to);
			try {
				lstHistory.setAdapter(adapter);
			} catch (Exception ex) {

			}

			lstHistory.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> paramAdapterView,
						View paramView, int position, long paramLong) {
					// TODO Auto-generated method stub
					try {
						String row = alldata.getJSONObject(position).toString();

						Bundle bundle = new Bundle();
						bundle.putString("ROWDATA", row);
						String value = lstHistory.getItemAtPosition(position)
								.toString();
						Intent historyDetailScreen = new Intent(History.this,
								History_Detail.class);

						historyDetailScreen.putExtras(bundle);
						History.this.startActivity(historyDetailScreen);
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
