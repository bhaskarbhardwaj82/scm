package com.signcatch.merchant;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Help extends Activity {
	private clsGeneral objGeneral;
	private Runnable runnable;
	Boolean running = false;
	static Dialog myDialog;

	Handler h = new Handler();
	static Context mContext;
	static Activity mActivity;

	EditText txtQuery;
	Button btnCallus, btnEmailus;
	ImageButton imgBtnSubmit;
	TextView tviEmail, tviCall;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help);
		getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		init();

		Bundle bundle = getIntent().getExtras();

		// Extract the data�
		final String userName = bundle.getString("userName");

		tviCall = (TextView) findViewById(R.id.tviCallus);
		tviEmail = (TextView) findViewById(R.id.tviEmailus);
		txtQuery = (EditText) findViewById(R.id.txtQuery);

		btnCallus = (Button) findViewById(R.id.btnCall_us);
		btnCallus.setVisibility(View.GONE);
		btnCallus.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				objGeneral.callPhone("+14087435949", mActivity, mContext);
			}
		});

		tviCall.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				objGeneral.callPhone("+14087435949", mActivity, mContext);
			}
		});
		btnEmailus = (Button) findViewById(R.id.btnEmail_us);
		btnEmailus.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(Intent.ACTION_SEND); // it's not
				// ACTION_SEND
				intent.setType("text/plain");

				intent.putExtra(Intent.EXTRA_EMAIL,
						new String[] { "admin@signcatch.com" });
				intent.putExtra(Intent.EXTRA_SUBJECT, "Help!!");
				intent.putExtra(Intent.EXTRA_TEXT, "");

				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // this will

				startActivity(intent);
			}
		});
		tviEmail.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(Intent.ACTION_SEND); // it's not
																// ACTION_SEND
				intent.setType("text/plain");

				intent.putExtra(Intent.EXTRA_EMAIL,
						new String[] { "admin@signcatch.com" });
				intent.putExtra(Intent.EXTRA_SUBJECT, "Help!!");
				intent.putExtra(Intent.EXTRA_TEXT, "");

				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				// this will make such that when us returns to your app,
				// your app is displayed, instead of the email app.
				startActivity(intent);
			}
		});

		imgBtnSubmit = (ImageButton) findViewById(R.id.imgBtnSubmit);
		imgBtnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (txtQuery.getText().toString().length() == 0) {

					objGeneral.ShowAlert(mContext, "Please enter your query");

				} else {
					Thread t = new Thread(new Runnable() {

						@Override
						public void run() {

							running = true;
							h.post(runnable);

							CallWebMethods oCallWebMethods = new CallWebMethods();
							final String returnValue = oCallWebMethods.Help(
									mContext, userName, txtQuery.getText()
											.toString());

							if (returnValue == null) {
								runOnUiThread(new Runnable() {
									public void run() {

										objGeneral.ShowAlert(mContext,
												objGeneral.NOINTERNET);
									}
								});

							} else if (returnValue
									.equals(objGeneral.NOINTERNET)) {
								runOnUiThread(new Runnable() {
									public void run() {

										objGeneral.ShowAlert(mContext,
												objGeneral.NOINTERNET);
									}
								});

							} else {
								if (returnValue.split("~")[0].toString()
										.equals("0")) {
									final String tmpVal = returnValue
											.split("~")[1].toString();
									runOnUiThread(new Runnable() {
										public void run() {

											objGeneral.ShowAlert(mContext,
													tmpVal);
										}
									});
								} else {
									runOnUiThread(new Runnable() {
										public void run() { 
											String str = returnValue.split("~")[1]
													.toString();

											objGeneral.ShowAlertAndFinish(
													mContext, str, mActivity);// (mContext,"Successfully Loggedin");

										}
									});

								}

							}
							running = false;
							h.post(runnable);
						}
					});
					t.start();
				}

			}
		});
	}

	// @Override
	// public void onUserInteraction() {
	//
	// MyTimerClass.startTimer();
	//
	// }

	private void init() {
		objGeneral = new clsGeneral();
		objGeneral.InitLoadPopup(this,
				(ViewGroup) findViewById(R.id.layout_root));

		mContext = Help.this;
		mActivity = Help.this;

		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}

	// public void logout() {
	// // TODO Auto-generated method stub
	// // Intent login = new Intent(mContext, LoginActivity.class);
	// // startActivity(login);
	// }

}
