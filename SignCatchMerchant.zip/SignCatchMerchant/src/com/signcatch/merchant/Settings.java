package com.signcatch.merchant;

import com.signcatch.merchant.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

public class Settings extends Activity {
	// init start
	private clsGeneral objGeneral;
	private Runnable runnable;
	Boolean running = false;
	Handler h = new Handler();
	Context mContext;
	Activity mActivity;
	// //init close
    TextView mDisplay;
    AsyncTask<Void, Void, Void> mRegisterTask;

	CheckBox chkShowProductInfo;
	CheckBox chkShowSignCatch;
	EditText txtDeviceID;
	ToggleButton tbtPushNotification;
	
	TextView lblmyIMEI;
    

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setttings);
		init();
		txtDeviceID = (EditText) findViewById(R.id.txtDeviceID);
		chkShowProductInfo = (CheckBox) findViewById(R.id.chkShowProductInfo);
		chkShowSignCatch = (CheckBox) findViewById(R.id.chkShowSignCatch);
		lblmyIMEI= (TextView)findViewById(R.id.lblmyIMEI);
		tbtPushNotification = (ToggleButton)findViewById(R.id.tbtPushNotification);
		
		lblmyIMEI.setText(objGeneral.getIMEI(mContext));
		
		if(objGeneral.getSharedPreferencesValue(getApplicationContext(), "PUSHNOTIFICATION").equals("1"))
		{
			tbtPushNotification.setChecked(true);
		}else
		{
			tbtPushNotification.setChecked(false);
		}
		txtDeviceID.setText(objGeneral.getSharedPreferencesValue(
				getApplicationContext(), "DeviceID"));
		if (objGeneral.getSharedPreferencesValue(getApplicationContext(),
				"ShowProductInfo").equals("0")) {
			chkShowProductInfo.setChecked(false);
		} else {
			chkShowProductInfo.setChecked(true);
		}

		if (objGeneral.getSharedPreferencesValue(getApplicationContext(),
				"ShowSignCatch").equals("0")) {
			chkShowSignCatch.setChecked(false);
		} else {
			chkShowSignCatch.setChecked(true);
		}
		Button btnClose = (Button) findViewById(R.id.btnClose);
		btnClose.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});

		Button btnSave = (Button)findViewById(R.id.btnSave);
		btnSave.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String showSignCatch ="0";
				if(chkShowSignCatch.isChecked())
				{
					showSignCatch ="1";
				}
				String showProductInfo ="0";
				if(chkShowProductInfo.isChecked())
				{
					showProductInfo ="1";
				}
				objGeneral.setSharedPreferencesValue(getApplicationContext(), "DeviceID", txtDeviceID.getText().toString());
				objGeneral.setSharedPreferencesValue(getApplicationContext(), "ShowProductInfo", showProductInfo);
				objGeneral.setSharedPreferencesValue(getApplicationContext(), "ShowSignCatch", showSignCatch);
				
				if(tbtPushNotification.isChecked()==true)
				{
					objGeneral.setSharedPreferencesValue(getApplicationContext(), "PUSHNOTIFICATION", "1");
				} else
				{
					objGeneral.setSharedPreferencesValue(getApplicationContext(), "PUSHNOTIFICATION", "0");
				}
				
				
				
			finish();	
			}
		});
	}

	private void init() {
		objGeneral = new clsGeneral();
		objGeneral.InitLoadPopup(this,
				(ViewGroup) findViewById(R.id.layout_root));
		mContext = Settings.this;
		mActivity = Settings.this;
		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}
}