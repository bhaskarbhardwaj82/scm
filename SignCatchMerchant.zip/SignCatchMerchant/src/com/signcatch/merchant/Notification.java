package com.signcatch.merchant;

import com.signcatch.merchant.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

public class Notification extends Activity{
	
	  @Override
	    public void onCreate(Bundle savedInstanceState) {
		  setContentView(R.layout.main);
		  
		  
		  String message = this.getIntent().getExtras().getString("message");
		  ShowAlert(this, message);
		  
	  }
	  public void ShowAlert(Context context, String msg) {
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setMessage(msg).setCancelable(true)
					.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
						}
					});
			AlertDialog alert = builder.create();
			try {
				alert.show();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

}
