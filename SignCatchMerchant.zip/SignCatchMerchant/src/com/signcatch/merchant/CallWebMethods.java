package com.signcatch.merchant;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;

import android.content.Context;

public class CallWebMethods {
	
	public CallWebMethods() {
		// TODO Auto-generated constructor stub
	};
	private String URL = "https://www.signcatch.com/webservice/webservice.php";

	private static final String NAMESPACE = "http://tempuri.org/";
	private String METHOD_NAME = "";
	clsWebService objWebService = new clsWebService();
	clsGeneral objGeneral = new clsGeneral();


	public String ValidateUser(Context context, String userid, String password) {
		Object[][] objBody = new Object[2][2];
		objBody[0][0] = "uname";
		objBody[0][1] = userid;
		objBody[1][0] = "pass";
		objBody[1][1] = password;
		METHOD_NAME = "login";

		Object[][] objHeader = new Object[2][2];
		objHeader[0][0] = "UserID";
		objHeader[0][1] = 0;

		objHeader[1][0] = "Password";
		objHeader[1][1] = "";

		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = false;
		SoapObject soRequest = new SoapObject(NAMESPACE, METHOD_NAME);
		Boolean readbody = true;
		Object objResult = objWebService.callWebmentodWithParameters(URL,
				METHOD_NAME, context, objBody, objHeader, envelope, soRequest,
				readbody);
		try {
			if (objResult == null)
				return null;
			else if (objResult.toString().equals(objGeneral.NOINTERNET)) {
				return objGeneral.NOINTERNET;
			} else if (objResult != null) {
				return objResult.toString();
			}
		} catch (Exception e) {
			return null;
		}
		return "";
	}

	public String getDeviceProduct(Context context, String deviceID) {
		Object[][] objBody = new Object[1][2];
		objBody[0][0] = "device_id";
		objBody[0][1] = deviceID;

		METHOD_NAME = "getDeviceProduct";

		Object[][] objHeader = new Object[2][2];
		objHeader[0][0] = "UserID";
		objHeader[0][1] = 0;

		objHeader[1][0] = "Password";
		objHeader[1][1] = "";

		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = false;
		SoapObject soRequest = new SoapObject(NAMESPACE, METHOD_NAME);
		Boolean readbody = true;
		Object objResult = objWebService.callWebmentodWithParameters(URL,
				METHOD_NAME, context, objBody, objHeader, envelope, soRequest,
				readbody);
		try {
			if (objResult == null)
				return null;
			else if (objResult.toString().equals(objGeneral.NOINTERNET)) {
				return objGeneral.NOINTERNET;
			} else if (objResult != null) {
				return objResult.toString();
			}
		} catch (Exception e) {
			return null;
		}
		return "";
	}

	public String AddProduct(Context context, String userid,
			String productName, String ProductDesc, String amount,
			String expiryDate, String deviceID) {
		Object[][] objBody = new Object[6][2];
		objBody[0][0] = "mechant_id";
		objBody[0][1] = userid;
		objBody[1][0] = "product_name";
		objBody[1][1] = productName;
		objBody[2][0] = "product_desc";
		objBody[2][1] = ProductDesc;
		objBody[3][0] = "price";
		objBody[3][1] = amount;
		objBody[4][0] = "expiry_date";
		objBody[4][1] = "2025-12-12";
		objBody[5][0] = "device_id";
		objBody[5][1] = deviceID;

		METHOD_NAME = "addproduct";

		Object[][] objHeader = new Object[2][2];
		objHeader[0][0] = "UserID";
		objHeader[0][1] = 0;

		objHeader[1][0] = "Password";
		objHeader[1][1] = "";

		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = false;
		SoapObject soRequest = new SoapObject(NAMESPACE, METHOD_NAME);
		Boolean readbody = true;
		Object objResult = objWebService.callWebmentodWithParameters(URL,
				METHOD_NAME, context, objBody, objHeader, envelope, soRequest,
				readbody);
		try {
			if (objResult == null)
				return null;
			else if (objResult.toString().equals(objGeneral.NOINTERNET)) {
				return objGeneral.NOINTERNET;
			} else if (objResult != null) {
				return objResult.toString();
			}
		} catch (Exception e) {
			return null;
		}
		return "";
	}

	public String AddCash(Context context, String userid,
			String productName, String ProductDesc, String amount,
			String expiryDate, String deviceID) {
		Object[][] objBody = new Object[5][2];
		objBody[0][0] = "mechant_id";
		objBody[0][1] = userid;
		objBody[1][0] = "productname";
		objBody[1][1] = productName;
		objBody[2][0] = "productdesc";
		objBody[2][1] = ProductDesc;
		objBody[3][0] = "amount";
		objBody[3][1] = amount;
		objBody[4][0] = "deviceid";
		objBody[4][1] = deviceID;

	    
		METHOD_NAME = "cashtransaction";

		Object[][] objHeader = new Object[2][2];
		objHeader[0][0] = "UserID";
		objHeader[0][1] = 0;

		objHeader[1][0] = "Password";
		objHeader[1][1] = "";

		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = false;
		SoapObject soRequest = new SoapObject(NAMESPACE, METHOD_NAME);
		Boolean readbody = true;
		Object objResult = objWebService.callWebmentodWithParameters(URL,
				METHOD_NAME, context, objBody, objHeader, envelope, soRequest,
				readbody);
		try {
			if (objResult == null)
				return null;
			else if (objResult.toString().equals(objGeneral.NOINTERNET)) {
				return objGeneral.NOINTERNET;
			} else if (objResult != null) {
				return objResult.toString();
			}
		} catch (Exception e) {
			return null;
		}
		return "";
	}
	public Object TransectionHistory(Context context, String userName, Integer startIndex, Integer limit) {
		// TODO Auto-generated method stub
		Object[][] objBody = new Object[3][2];
		objBody[0][0] = "uname";
		objBody[0][1] = userName;
		objBody[1][0] = "start";
		objBody[1][1] = startIndex;
		objBody[2][0] = "limit";
		objBody[2][1] = limit;
		

		METHOD_NAME = "getTransactionHistory";

		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = true;
		SoapObject soRequest = new SoapObject(NAMESPACE, METHOD_NAME);
		Boolean readbody = true;
		Object[][] objHeader = new Object[2][2];
		objHeader[0][0] = "UserID";
		objHeader[0][1] = 0;

		objHeader[1][0] = "Password";
		objHeader[1][1] = "";
		
		Object objResult = objWebService.callWebmentodWithParameters(URL,
				METHOD_NAME, context, objBody, objHeader, envelope, soRequest,
				readbody);

		try {
			if (objResult == null) {

				return null;

			} else if (objResult.toString().equals(objGeneral.NOINTERNET)) {

				return objGeneral.NOINTERNET;
			} else if (objResult != null) {

				return objResult;

			}
		} catch (Exception e) {

			return null;
		}
		return null;
	}
	public String CheckAppVersion(Context context) {
		// TODO Auto-generated method stub
		Object[][] objBody = new Object[1][2];
		objBody[0][0]="app_type";
		objBody[0][1]="3";
		  
		METHOD_NAME = "AppVersion";

		/*
		 * Object[][] objHeader = new Object[1][2]; objHeader[0][0] = "UserID";
		 * objHeader[0][1] = 0;
		 */

		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = true;
		SoapObject soRequest = new SoapObject(NAMESPACE, METHOD_NAME);
		Boolean readbody = true;
		Object[][] objHeader = new Object[2][2];
		objHeader[0][0] = "UserID";
		objHeader[0][1] = 0;

		objHeader[1][0] = "Password";
		objHeader[1][1] = "";
		Object objResult = objWebService.callWebmentodWithParameters(URL,
				METHOD_NAME, context, objBody, objHeader, envelope, soRequest,
				readbody);
		
		try {
			if (objResult == null) {

				return "";

			} else if (objResult.toString().equals(objGeneral.NOINTERNET)) {

				return objGeneral.NOINTERNET;
			} else if (objResult != null) {

				return objResult.toString();

			}
		} catch (Exception e) {

			return null;
		}
		return "";
	}
	public String Help(Context context, String userName, String query) {
		// TODO Auto-generated method stub
		Object[][] objBody = new Object[2][2];
		objBody[0][0] = "user_id";
		objBody[0][1] = userName;
		objBody[1][0] = "query";
		objBody[1][1] = query;

		Object[][] objHeader = new Object[2][2];
		objHeader[0][0] = "UserID";
		objHeader[0][1] = 0;

		METHOD_NAME = "help";

		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = true;
		SoapObject soRequest = new SoapObject(NAMESPACE, METHOD_NAME);
		Boolean readbody = true;

		Object objResult = objWebService.callWebmentodWithParameters(URL,
				METHOD_NAME, context, objBody, objHeader, envelope, soRequest, readbody);

		try {
			if (objResult == null) {

				return null;

			} else if (objResult.toString().equals(objGeneral.NOINTERNET)) {

				return objGeneral.NOINTERNET;
			} else if (objResult != null) {

				return objResult.toString();

			}
		} catch (Exception e) {

			return null;
		}
		return null;
	}

}
