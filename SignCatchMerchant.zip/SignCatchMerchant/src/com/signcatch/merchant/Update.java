package com.signcatch.merchant;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;


public class Update extends Activity {
	private clsGeneral objGeneral;
	private Runnable runnable;
	Boolean running = false;

	Handler h = new Handler();
	Context mContext;
	Activity mActivity;

	Button btnSubmit, btnCancel;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.update);
		init();

		Bundle bundle = getIntent().getExtras();

		// Extract the data�
		final String userName = bundle.getString("userName");

		btnSubmit = (Button) findViewById(R.id.btnSubmit);
		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Thread t = new Thread(new Runnable() {

					@Override
					public void run() {

						running = true;
						h.post(runnable);

						CallWebMethods objCallWebMethods = new CallWebMethods();
						String outValue = objCallWebMethods
								.CheckAppVersion(mContext);

						if (outValue.equals("") == false) {
							final String[] values = outValue.split("~");
							if (values[0].equals("0")) {
								runOnUiThread(new Runnable() {
									public void run() {
										objGeneral.ShowAlert(mContext,
												objGeneral.NOINTERNET);
									}
								});
							} else {
								if (values[0].equals(getResources().getString(R.string.version_no)) == false) {
									runOnUiThread(new Runnable() {
										public void run() {
											AlertDialog.Builder builder = new AlertDialog.Builder(
													mContext);
											builder.setMessage(
													"A newer version of the SignCatch is available, want to download")
													.setCancelable(false)
													.setPositiveButton(
															"Yes",
															new DialogInterface.OnClickListener() {
																public void onClick(
																		DialogInterface dialog,
																		int id) {
																	dialog.cancel();

																	runOnUiThread(new Runnable() {
																		public void run() {
																			String url = values[1];
																			if (values[1]
																					.contains("http") == false) {
																				url = "http://"
																						+ values[1];
																			}
																			Uri uri = Uri
																					.parse(url);
																			Intent intent = new Intent(
																					Intent.ACTION_VIEW,
																					uri);

																			try {
																				mContext.startActivity(intent);
																			} catch (Exception e) {
																				// TODO
																				// Auto-generated
																				// catch
																				// block
																				e.printStackTrace();
																			}

																		}
																	});

																}
															})
													.setNegativeButton(
															"No",
															new DialogInterface.OnClickListener() {
																public void onClick(
																		DialogInterface dialog,
																		int id) {
																	dialog.cancel();
																}
															});

											AlertDialog alert = builder
													.create();
											try {
												alert.show();
											} catch (Exception ex) {
												ex.printStackTrace();
											}

										}
									});

								} else {
									runOnUiThread(new Runnable() {
										public void run() {
											objGeneral
													.ShowAlert(mContext,
															"You are using latest version of the SignCatch!");

										}
									});
								}
							}

						} else {
							runOnUiThread(new Runnable() {
								public void run() {
									objGeneral.ShowAlert(mContext,
											objGeneral.NOINTERNET);
								}
							});
						}
						running = false;
						h.post(runnable);
					}
				});
				t.start();

			}

		});

		btnCancel = (Button) findViewById(R.id.btnCancel);
		btnCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});

	}

	private void init() {
		objGeneral = new clsGeneral();
		objGeneral.InitLoadPopup(this,
				(ViewGroup) findViewById(R.id.layout_root));
		mContext = Update.this;
		mActivity = Update.this;
		runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (running == true) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							objGeneral.ShowLoadPopup();
						}
					});

				} else {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (running == false) {
								objGeneral.HideLoadPopup();

							}
						}
					});

				}
			}
		};
		running = false;
		h.post(runnable);

	}

}
