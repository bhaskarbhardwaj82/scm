/*********************************************************************************
* Created by		: 	Bhaskar Bhardwaj
* Dated				:	08th Mar 2011
* Desc				:	This class can be used to call a web service method
* 
* Public Functions	:	
* 
**********************************************************************************/


package com.signcatch.merchant;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.Marshal;
import org.ksoap2.serialization.MarshalDate;
import org.ksoap2.serialization.MarshalFloat;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.AndroidHttpTransport;
import org.kxml2.kdom.Element;
import org.kxml2.kdom.Node;


import android.R.layout;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.widget.Toast;


public class clsWebService 
{
	private static final String NAMESPACE = "urn:stockquote";
	public ProgressDialog pd;
	private boolean running=false;
	private  String strReturnValue = "";
	private String METHOD_NAME = "";
	private static final String SOAP_ACTION = "urn:stockquote#" ;
	private clsGeneral objGeneral =new clsGeneral();
	private Integer TimeOut=60000;
	public Object callWebmentod(String URL, String MethodName,Context context)
	{
		if (objGeneral.CheckInternet(context)==false)
		{
			return objGeneral.NOINTERNET;
		}
		Object objRetvalue = new Object();
			try
			{
			METHOD_NAME=MethodName;
			SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = request;
			envelope.dotNet = true;
	        envelope.implicitTypes = true;
	        envelope.encodingStyle = "utf-8";
	        envelope.enc = SoapSerializationEnvelope.ENC2003;
	        envelope.xsd = SoapEnvelope.XSD;
	        envelope.xsi = SoapEnvelope.XSI;
	        envelope.encodingStyle = SoapSerializationEnvelope.ENC; 
	        envelope.setOutputSoapObject(request);
	        AndroidHttpTransport androidHttpTransport = new AndroidHttpTransport(URL,TimeOut);
	        
	        androidHttpTransport.call(SOAP_ACTION+METHOD_NAME,envelope);

	        objRetvalue = envelope.getResponse();
	        
	        }
			catch(Exception ex)
			{
				objRetvalue = objGeneral.NOINTERNET;
				ex.printStackTrace();
				objRetvalue=null;
			}
		return objRetvalue;
	}
	public Object callWebmentodWithParameters(String URL, String MethodName,Context context, Object[][] bodyProperty,Object[][] headerProperty, SoapSerializationEnvelope envelope, SoapObject request, Boolean readbody)
	{
		if (objGeneral.CheckInternet(context)==false)
		{
			return objGeneral.NOINTERNET;
		}
		Object result = new Object();
			try
			{
			METHOD_NAME=MethodName;
			if (readbody==true)
			{
				for (int i=0; i<bodyProperty.length; i++)
				{
					if (bodyProperty[i][0]!=null)
					{
						request.addProperty(bodyProperty[i][0].toString(), bodyProperty[i][1]);
					}
				}
			}
			if (headerProperty.length >0)
			{
				 Element[] header = new Element[1];
				 header[0] = new Element().createElement(NAMESPACE, "AuthenticationHeader");
				  	for (int i=0; i<headerProperty.length; i++)
				  	{
				  		if (headerProperty[i][0]!=null)
				  		{
				  				Element appname = new Element().createElement(NAMESPACE, headerProperty[i][0].toString()); 
				  		        appname.addChild(Node.TEXT, headerProperty[i][1].toString()); 
				  		      header[0].addChild(Node.ELEMENT, appname); 
				  		}
				  	}
		  	envelope.headerOut=header;
				
			}
//			Element[] header1 = new Element[headerProperty.length]; 
//			Element usernameElement = new Element().createElement(NAMESPACE, "UserID");   
//			usernameElement.addChild(Node.TEXT, "12222");
//			header1[0]= usernameElement;
//			Element passwordElement = new Element().createElement(NAMESPACE, "Password");   
//			passwordElement.addChild(Node.TEXT, "mbi?#905pqc");
//			header1[1] = passwordElement;
//			envelope.headerOut=header1;
			
//			if (tablename.toLowerCase().equals("bouserregister"))
//			{
//				envelope.dotNet=true;
//				BOUserRegister  objboUserRegister = (BOUserRegister) bodyProperty[0][1];
//				request.addProperty(bodyProperty[0][0].toString(), objboUserRegister);
//				envelope.addMapping(NAMESPACE, BOUserRegister.USERREGISTER_CLASS.getSimpleName(),
//						BOUserRegister.USERREGISTER_CLASS);
//				
//			}
			Marshal floatMarshal =  new MarshalFloat();
			floatMarshal.register(envelope);
			Marshal dateMarshal= new MarshalDate();
			dateMarshal.register(envelope);
			envelope.bodyOut = request;
			envelope.dotNet = false;
	        envelope.implicitTypes = true;
	        envelope.encodingStyle = "utf-8";
	        envelope.enc = SoapSerializationEnvelope.ENC;
	        envelope.xsd = SoapEnvelope.XSD;
	        envelope.xsi = SoapEnvelope.XSI;
	        envelope.encodingStyle = SoapSerializationEnvelope.ENC; 
	        envelope.setOutputSoapObject(request);
	        AndroidHttpTransport androidHttpTransport = new AndroidHttpTransport(URL,TimeOut);
	        androidHttpTransport.debug=true;
	        androidHttpTransport.call(SOAP_ACTION+METHOD_NAME,envelope);
	        
	        result = envelope.getResponse();
			}
			catch(Exception ex)
			{
				return null;
			}
			
//			DefaultHttpClient httpClient = new DefaultHttpClient();
//			HttpPost httpPost = new HttpPost(url); // url = webpage u send data with request
//			httpPost.setEntity(new UrlEncodedFormEntity(params)); //params is a List<NameValuePair> where you store your value to send server
//
//			HttpResponse httpResponse = httpClient.execute(httpPost);
//			HttpEntity httpEntity = httpResponse.getEntity();
//			is = httpEntity.getContent(); //is is an InputStream

			
		return result;
	}
	
	public Object callWebmentodWithoutParameters(String URL, String MethodName,Context context, Object[][] headerProperty, SoapSerializationEnvelope envelope, SoapObject request)
	{
		if (objGeneral.CheckInternet(context)==false)
		{
			return objGeneral.NOINTERNET;
		}
		Object result = new Object();
			try
			{
			METHOD_NAME=MethodName;
			if (headerProperty.length >0)
			{
				Element[] header = new Element[1];
				 header[0] = new Element().createElement(NAMESPACE, "AuthenticationHeader");
				  	for (int i=0; i<headerProperty.length; i++)
				  	{
				  		if (headerProperty[i][0]!=null)
				  		{
				  				Element appname = new Element().createElement(NAMESPACE, headerProperty[i][0].toString()); 
				  		        appname.addChild(Node.TEXT, headerProperty[i][1].toString()); 
				  		      header[0].addChild(Node.ELEMENT, appname); 
				  		}
				  	}
		  	envelope.headerOut=header;
			}
			
			Marshal floatMarshal =  new MarshalFloat();
			floatMarshal.register(envelope);
			Marshal dateMarshal= new MarshalDate();
			dateMarshal.register(envelope);
			envelope.bodyOut = request;
			envelope.dotNet = true;
	        envelope.implicitTypes = true;
	        envelope.encodingStyle = "utf-8";
	        envelope.enc = SoapSerializationEnvelope.ENC2003;
	        envelope.xsd = SoapEnvelope.XSD;
	        envelope.xsi = SoapEnvelope.XSI;
	        envelope.encodingStyle = SoapSerializationEnvelope.ENC; 
	        envelope.setOutputSoapObject(request);
	        AndroidHttpTransport androidHttpTransport = new AndroidHttpTransport(URL,TimeOut);
	        androidHttpTransport.call(SOAP_ACTION+METHOD_NAME,envelope);

	        result = envelope.getResponse();
			}
			catch(Exception ex)
			{
				result=objGeneral.NOINTERNET;
				ex.printStackTrace();
				result = null;
			}
		return result;
	}

}
